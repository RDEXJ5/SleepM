import React, { useState } from 'react';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import SleepLog from './components/SleepLog';
import Analytics from './components/Analytics';
import Recommendations from './components/Recommendations';
import { SleepData, SleepEntry } from './types/sleep';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sleepData, setSleepData] = useState<SleepData>({
    entries: [
      {
        id: '1',
        date: '2025-01-20',
        bedtime: '23:30',
        wakeTime: '07:15',
        duration: 7.75,
        quality: 4,
        notes: 'Slept well, felt refreshed'
      },
      {
        id: '2',
        date: '2025-01-19',
        bedtime: '00:15',
        wakeTime: '07:30',
        duration: 7.25,
        quality: 3,
        notes: 'Took a while to fall asleep'
      },
      {
        id: '3',
        date: '2025-01-18',
        bedtime: '23:45',
        wakeTime: '06:45',
        duration: 7,
        quality: 5,
        notes: 'Perfect night of sleep'
      },
      {
        id: '4',
        date: '2025-01-17',
        bedtime: '00:30',
        wakeTime: '08:00',
        duration: 7.5,
        quality: 3,
        notes: 'Woke up several times'
      },
      {
        id: '5',
        date: '2025-01-16',
        bedtime: '23:00',
        wakeTime: '07:00',
        duration: 8,
        quality: 4,
        notes: 'Good solid sleep'
      }
    ],
    goals: {
      targetSleepHours: 8,
      targetBedtime: '23:00',
      targetWakeTime: '07:00'
    }
  });

  const addSleepEntry = (entry: Omit<SleepEntry, 'id'>) => {
    const newEntry: SleepEntry = {
      ...entry,
      id: Date.now().toString()
    };
    
    setSleepData(prev => ({
      ...prev,
      entries: [newEntry, ...prev.entries]
    }));
  };

  const renderActiveTab = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard sleepData={sleepData} />;
      case 'log':
        return <SleepLog onAddEntry={addSleepEntry} />;
      case 'analytics':
        return <Analytics sleepData={sleepData} />;
      case 'recommendations':
        return <Recommendations sleepData={sleepData} />;
      default:
        return <Dashboard sleepData={sleepData} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900">
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="container mx-auto px-4 py-8">
        {renderActiveTab()}
      </main>
    </div>
  );
}

export default App;
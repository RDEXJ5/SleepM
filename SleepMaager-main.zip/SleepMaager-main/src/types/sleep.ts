export interface SleepEntry {
  id: string;
  date: string;
  bedtime: string;
  wakeTime: string;
  duration: number;
  quality: number; // 1-5 scale
  notes?: string;
}

export interface SleepGoals {
  targetSleepHours: number;
  targetBedtime: string;
  targetWakeTime: string;
}

export interface SleepData {
  entries: SleepEntry[];
  goals: SleepGoals;
}
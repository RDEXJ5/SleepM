import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface StatsCardProps {
  title: string;
  value: string;
  unit: string;
  icon: LucideIcon;
  color: 'blue' | 'yellow' | 'green' | 'purple';
}

const StatsCard: React.FC<StatsCardProps> = ({ title, value, unit, icon: Icon, color }) => {
  const colorClasses = {
    blue: 'from-blue-500 to-cyan-500',
    yellow: 'from-yellow-500 to-orange-500',
    green: 'from-green-500 to-emerald-500',
    purple: 'from-purple-500 to-indigo-500'
  };

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20 hover:bg-white/15 transition-all duration-200">
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-lg bg-gradient-to-r ${colorClasses[color]}`}>
          <Icon className="h-6 w-6 text-white" />
        </div>
      </div>
      <div className="space-y-1">
        <p className="text-white/70 text-sm font-medium">{title}</p>
        <div className="flex items-baseline space-x-1">
          <span className="text-2xl font-bold text-white">{value}</span>
          <span className="text-white/60 text-sm">{unit}</span>
        </div>
      </div>
    </div>
  );
};

export default StatsCard;
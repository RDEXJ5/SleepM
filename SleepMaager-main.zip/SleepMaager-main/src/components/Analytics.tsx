import React from 'react';
import { SleepData } from '../types/sleep';
import { TrendingUp, Calendar, Clock, Star } from 'lucide-react';

interface AnalyticsProps {
  sleepData: SleepData;
}

const Analytics: React.FC<AnalyticsProps> = ({ sleepData }) => {
  const { entries } = sleepData;
  
  // Calculate weekly averages
  const weeklyData = entries.slice(0, 7);
  const monthlyData = entries.slice(0, 30);
  
  const weeklyAvgHours = weeklyData.reduce((sum, entry) => sum + entry.duration, 0) / weeklyData.length;
  const monthlyAvgHours = monthlyData.reduce((sum, entry) => sum + entry.duration, 0) / monthlyData.length;
  const weeklyAvgQuality = weeklyData.reduce((sum, entry) => sum + entry.quality, 0) / weeklyData.length;
  const monthlyAvgQuality = monthlyData.reduce((sum, entry) => sum + entry.quality, 0) / monthlyData.length;

  // Calculate sleep patterns
  const bedtimePattern = entries.map(entry => {
    const [hours, minutes] = entry.bedtime.split(':').map(Number);
    return hours + minutes / 60;
  });
  const avgBedtime = bedtimePattern.reduce((sum, time) => sum + time, 0) / bedtimePattern.length;
  
  const qualityDistribution = {
    excellent: entries.filter(e => e.quality >= 4).length,
    good: entries.filter(e => e.quality === 3).length,
    poor: entries.filter(e => e.quality <= 2).length
  };

  const formatTime = (decimalHours: number) => {
    const hours = Math.floor(decimalHours);
    const minutes = Math.round((decimalHours - hours) * 60);
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-8">
      <div className="text-center text-white">
        <h2 className="text-3xl font-bold mb-2">Sleep Analytics</h2>
        <p className="text-white/80 text-lg">Insights into your sleep patterns</p>
      </div>

      {/* Time Period Comparison */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
          <div className="flex items-center space-x-3 mb-4">
            <Calendar className="h-6 w-6 text-blue-400" />
            <h3 className="text-xl font-semibold text-white">Weekly Average</h3>
          </div>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-white/80">Sleep Duration</span>
              <span className="text-2xl font-bold text-blue-300">{weeklyAvgHours.toFixed(1)}h</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-white/80">Sleep Quality</span>
              <div className="flex items-center space-x-2">
                <span className="text-2xl font-bold text-yellow-300">{weeklyAvgQuality.toFixed(1)}</span>
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < Math.round(weeklyAvgQuality) ? 'text-yellow-400 fill-current' : 'text-white/30'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
          <div className="flex items-center space-x-3 mb-4">
            <TrendingUp className="h-6 w-6 text-green-400" />
            <h3 className="text-xl font-semibold text-white">Monthly Average</h3>
          </div>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-white/80">Sleep Duration</span>
              <span className="text-2xl font-bold text-green-300">{monthlyAvgHours.toFixed(1)}h</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-white/80">Sleep Quality</span>
              <div className="flex items-center space-x-2">
                <span className="text-2xl font-bold text-yellow-300">{monthlyAvgQuality.toFixed(1)}</span>
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < Math.round(monthlyAvgQuality) ? 'text-yellow-400 fill-current' : 'text-white/30'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Sleep Patterns */}
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h3 className="text-xl font-semibold text-white mb-6">Sleep Patterns</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="flex items-center justify-center mb-3">
              <Clock className="h-8 w-8 text-purple-400" />
            </div>
            <div className="text-2xl font-bold text-purple-300 mb-1">
              {formatTime(avgBedtime)}
            </div>
            <div className="text-white/70 text-sm">Average Bedtime</div>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center mb-3">
              <TrendingUp className="h-8 w-8 text-cyan-400" />
            </div>
            <div className="text-2xl font-bold text-cyan-300 mb-1">
              {((weeklyAvgHours - monthlyAvgHours) >= 0 ? '+' : '')}{(weeklyAvgHours - monthlyAvgHours).toFixed(1)}h
            </div>
            <div className="text-white/70 text-sm">Weekly Trend</div>
          </div>
          
          <div className="text-center">
            <div className="flex items-center justify-center mb-3">
              <Star className="h-8 w-8 text-yellow-400" />
            </div>
            <div className="text-2xl font-bold text-yellow-300 mb-1">
              {Math.max(...entries.map(e => e.quality))}
            </div>
            <div className="text-white/70 text-sm">Best Quality Score</div>
          </div>
        </div>
      </div>

      {/* Quality Distribution */}
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h3 className="text-xl font-semibold text-white mb-6">Sleep Quality Distribution</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-4 h-4 bg-green-400 rounded"></div>
              <span className="text-white/80">Excellent Sleep (4-5 stars)</span>
            </div>
            <div className="flex items-center space-x-3">
              <span className="text-white font-semibold">{qualityDistribution.excellent} nights</span>
              <span className="text-white/60">
                {((qualityDistribution.excellent / entries.length) * 100).toFixed(0)}%
              </span>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-4 h-4 bg-yellow-400 rounded"></div>
              <span className="text-white/80">Good Sleep (3 stars)</span>
            </div>
            <div className="flex items-center space-x-3">
              <span className="text-white font-semibold">{qualityDistribution.good} nights</span>
              <span className="text-white/60">
                {((qualityDistribution.good / entries.length) * 100).toFixed(0)}%
              </span>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-4 h-4 bg-red-400 rounded"></div>
              <span className="text-white/80">Poor Sleep (1-2 stars)</span>
            </div>
            <div className="flex items-center space-x-3">
              <span className="text-white font-semibold">{qualityDistribution.poor} nights</span>
              <span className="text-white/60">
                {((qualityDistribution.poor / entries.length) * 100).toFixed(0)}%
              </span>
            </div>
          </div>
        </div>
        
        {/* Visual Progress Bars */}
        <div className="mt-6 space-y-3">
          <div className="w-full bg-white/20 rounded-full h-2">
            <div 
              className="bg-green-400 h-2 rounded-full transition-all duration-500"
              style={{ width: `${(qualityDistribution.excellent / entries.length) * 100}%` }}
            ></div>
          </div>
          <div className="w-full bg-white/20 rounded-full h-2">
            <div 
              className="bg-yellow-400 h-2 rounded-full transition-all duration-500"
              style={{ width: `${(qualityDistribution.good / entries.length) * 100}%` }}
            ></div>
          </div>
          <div className="w-full bg-white/20 rounded-full h-2">
            <div 
              className="bg-red-400 h-2 rounded-full transition-all duration-500"
              style={{ width: `${(qualityDistribution.poor / entries.length) * 100}%` }}
            ></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
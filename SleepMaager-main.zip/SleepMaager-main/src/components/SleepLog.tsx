import React, { useState } from 'react';
import { SleepEntry } from '../types/sleep';
import { Plus, Star, Clock } from 'lucide-react';

interface SleepLogProps {
  onAddEntry: (entry: Omit<SleepEntry, 'id'>) => void;
}

const SleepLog: React.FC<SleepLogProps> = ({ onAddEntry }) => {
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    bedtime: '',
    wakeTime: '',
    quality: 3,
    notes: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const bedtimeHours = parseInt(formData.bedtime.split(':')[0]);
    const bedtimeMinutes = parseInt(formData.bedtime.split(':')[1]);
    const wakeTimeHours = parseInt(formData.wakeTime.split(':')[0]);
    const wakeTimeMinutes = parseInt(formData.wakeTime.split(':')[1]);
    
    let duration = (wakeTimeHours + wakeTimeMinutes / 60) - (bedtimeHours + bedtimeMinutes / 60);
    if (duration < 0) duration += 24; // Handle overnight sleep
    
    const newEntry: Omit<SleepEntry, 'id'> = {
      ...formData,
      duration: parseFloat(duration.toFixed(2))
    };
    
    onAddEntry(newEntry);
    setFormData({
      date: new Date().toISOString().split('T')[0],
      bedtime: '',
      wakeTime: '',
      quality: 3,
      notes: ''
    });
    setShowForm(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Sleep Log</h2>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center space-x-2 bg-gradient-to-r from-purple-500 to-blue-600 text-white px-4 py-2 rounded-lg hover:from-purple-600 hover:to-blue-700 transition-all duration-200"
        >
          <Plus className="h-4 w-4" />
          <span>Add Sleep Entry</span>
        </button>
      </div>

      {showForm && (
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
          <h3 className="text-xl font-semibold text-white mb-4">Log Your Sleep</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-white/80 text-sm font-medium mb-2">Date</label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({...formData, date: e.target.value})}
                  className="w-full px-3 py-2 bg-white/20 border border-white/30 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-white/80 text-sm font-medium mb-2">Sleep Quality</label>
                <div className="flex items-center space-x-2">
                  {[1, 2, 3, 4, 5].map((rating) => (
                    <button
                      key={rating}
                      type="button"
                      onClick={() => setFormData({...formData, quality: rating})}
                      className="p-1"
                    >
                      <Star
                        className={`h-6 w-6 ${
                          rating <= formData.quality 
                            ? 'text-yellow-400 fill-current' 
                            : 'text-white/30'
                        } hover:text-yellow-300 transition-colors`}
                      />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-white/80 text-sm font-medium mb-2">Bedtime</label>
                <input
                  type="time"
                  value={formData.bedtime}
                  onChange={(e) => setFormData({...formData, bedtime: e.target.value})}
                  className="w-full px-3 py-2 bg-white/20 border border-white/30 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-white/80 text-sm font-medium mb-2">Wake Time</label>
                <input
                  type="time"
                  value={formData.wakeTime}
                  onChange={(e) => setFormData({...formData, wakeTime: e.target.value})}
                  className="w-full px-3 py-2 bg-white/20 border border-white/30 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-white/80 text-sm font-medium mb-2">Notes (Optional)</label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({...formData, notes: e.target.value})}
                placeholder="How did you sleep? Any factors that affected your sleep?"
                className="w-full px-3 py-2 bg-white/20 border border-white/30 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500 h-20 resize-none"
              />
            </div>

            <div className="flex space-x-3">
              <button
                type="submit"
                className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 text-white py-2 px-4 rounded-lg hover:from-green-600 hover:to-emerald-700 transition-all duration-200 font-medium"
              >
                Save Sleep Entry
              </button>
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="px-4 py-2 text-white/70 hover:text-white transition-colors"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h3 className="text-lg font-semibold text-white mb-4">Quick Log Last Night</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { hours: 6, quality: 3, label: '6h - Fair' },
            { hours: 7, quality: 4, label: '7h - Good' },
            { hours: 8, quality: 4, label: '8h - Good' },
            { hours: 9, quality: 5, label: '9h - Excellent' }
          ].map((option, index) => (
            <button
              key={index}
              onClick={() => {
                const now = new Date();
                const wakeTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
                const bedtimeHour = now.getHours() - option.hours;
                const bedtime = `${(bedtimeHour < 0 ? bedtimeHour + 24 : bedtimeHour).toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
                
                onAddEntry({
                  date: now.toISOString().split('T')[0],
                  bedtime,
                  wakeTime,
                  duration: option.hours,
                  quality: option.quality,
                  notes: 'Quick logged entry'
                });
              }}
              className="bg-white/20 hover:bg-white/30 border border-white/30 rounded-lg p-4 text-white transition-all duration-200 group"
            >
              <div className="flex items-center justify-center mb-2">
                <Clock className="h-5 w-5 text-blue-300 group-hover:text-blue-200" />
              </div>
              <div className="text-sm font-medium">{option.label}</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SleepLog;
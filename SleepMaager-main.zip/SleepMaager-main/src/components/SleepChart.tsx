import React from 'react';
import { SleepEntry } from '../types/sleep';

interface SleepChartProps {
  entries: SleepEntry[];
}

const SleepChart: React.FC<SleepChartProps> = ({ entries }) => {
  const maxHours = Math.max(...entries.map(entry => entry.duration));
  const chartHeight = 200;

  return (
    <div className="space-y-4">
      <div className="flex items-end justify-between h-48 space-x-3">
        {entries.reverse().map((entry, index) => {
          const barHeight = (entry.duration / maxHours) * chartHeight;
          const qualityColor = entry.quality >= 4 ? 'bg-green-400' : entry.quality >= 3 ? 'bg-yellow-400' : 'bg-red-400';
          
          return (
            <div key={entry.id} className="flex-1 flex flex-col items-center">
              <div 
                className={`w-full rounded-t-lg ${qualityColor} transition-all duration-300 hover:opacity-80`}
                style={{ height: `${barHeight}px` }}
                title={`${entry.duration}h - Quality: ${entry.quality}/5`}
              />
              <div className="mt-2 text-center">
                <div className="text-white text-xs font-medium">{entry.duration}h</div>
                <div className="text-white/60 text-xs">
                  {new Date(entry.date).toLocaleDateString('en', { weekday: 'short' })}
                </div>
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="flex justify-center space-x-6 text-sm">
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-green-400 rounded"></div>
          <span className="text-white/70">Excellent (4-5)</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-yellow-400 rounded"></div>
          <span className="text-white/70">Good (3)</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-red-400 rounded"></div>
          <span className="text-white/70">Poor (1-2)</span>
        </div>
      </div>
    </div>
  );
};

export default SleepChart;
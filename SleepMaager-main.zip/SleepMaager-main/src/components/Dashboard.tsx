import React from 'react';
import { SleepData } from '../types/sleep';
import { Clock, Target, TrendingUp, Star } from 'lucide-react';
import StatsCard from './StatsCard';
import SleepChart from './SleepChart';

interface DashboardProps {
  sleepData: SleepData;
}

const Dashboard: React.FC<DashboardProps> = ({ sleepData }) => {
  const recentEntries = sleepData.entries.slice(0, 7);
  const avgSleepHours = recentEntries.reduce((sum, entry) => sum + entry.duration, 0) / recentEntries.length;
  const avgQuality = recentEntries.reduce((sum, entry) => sum + entry.quality, 0) / recentEntries.length;
  const goalAchievement = (avgSleepHours / sleepData.goals.targetSleepHours) * 100;
  
  const lastNight = sleepData.entries[0];

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="text-center text-white">
        <h2 className="text-3xl font-bold mb-2">Good Morning!</h2>
        <p className="text-white/80 text-lg">How was your sleep last night?</p>
      </div>

      {/* Last Night Summary */}
      {lastNight && (
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
          <h3 className="text-xl font-semibold text-white mb-4">Last Night's Sleep</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-300">{lastNight.duration}h</div>
              <div className="text-white/70 text-sm">Sleep Duration</div>
            </div>
            <div className="text-center">
              <div className="flex justify-center mb-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < lastNight.quality ? 'text-yellow-400 fill-current' : 'text-white/30'
                    }`}
                  />
                ))}
              </div>
              <div className="text-white/70 text-sm">Sleep Quality</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-300">{lastNight.bedtime}</div>
              <div className="text-white/70 text-sm">Bedtime</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-300">{lastNight.wakeTime}</div>
              <div className="text-white/70 text-sm">Wake Time</div>
            </div>
          </div>
        </div>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Avg Sleep Hours"
          value={avgSleepHours.toFixed(1)}
          unit="hours"
          icon={Clock}
          color="blue"
        />
        <StatsCard
          title="Sleep Quality"
          value={avgQuality.toFixed(1)}
          unit="/5"
          icon={Star}
          color="yellow"
        />
        <StatsCard
          title="Goal Achievement"
          value={goalAchievement.toFixed(0)}
          unit="%"
          icon={Target}
          color="green"
        />
        <StatsCard
          title="Sleep Consistency"
          value="85"
          unit="%"
          icon={TrendingUp}
          color="purple"
        />
      </div>

      {/* Sleep Chart */}
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h3 className="text-xl font-semibold text-white mb-6">Sleep Trends (Last 7 Days)</h3>
        <SleepChart entries={recentEntries} />
      </div>
    </div>
  );
};

export default Dashboard;
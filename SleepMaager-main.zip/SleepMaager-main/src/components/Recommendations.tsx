import React from 'react';
import { SleepData } from '../types/sleep';
import { Lightbulb, Moon, Sun, Coffee, Smartphone, Thermometer } from 'lucide-react';

interface RecommendationsProps {
  sleepData: SleepData;
}

const Recommendations: React.FC<RecommendationsProps> = ({ sleepData }) => {
  const recentEntries = sleepData.entries.slice(0, 7);
  const avgQuality = recentEntries.reduce((sum, entry) => sum + entry.quality, 0) / recentEntries.length;
  const avgDuration = recentEntries.reduce((sum, entry) => sum + entry.duration, 0) / recentEntries.length;
  
  const recommendations = [
    {
      icon: Moon,
      title: "Consistent Sleep Schedule",
      description: "Try to go to bed and wake up at the same time every day, even on weekends.",
      priority: avgQuality < 3 ? "high" : "medium",
      category: "schedule"
    },
    {
      icon: Smartphone,
      title: "Digital Detox Before Bed",
      description: "Avoid screens 1-2 hours before bedtime. Blue light can interfere with melatonin production.",
      priority: "high",
      category: "environment"
    },
    {
      icon: Thermometer,
      title: "Optimize Room Temperature",
      description: "Keep your bedroom between 60-67°F (15-19°C) for optimal sleep quality.",
      priority: "medium",
      category: "environment"
    },
    {
      icon: Coffee,
      title: "Watch Caffeine Intake",
      description: "Avoid caffeine 6 hours before bedtime. It can stay in your system longer than you think.",
      priority: avgQuality < 3.5 ? "high" : "low",
      category: "lifestyle"
    },
    {
      icon: Sun,
      title: "Morning Light Exposure",
      description: "Get 15-30 minutes of natural sunlight within the first hour of waking up.",
      priority: "medium",
      category: "lifestyle"
    },
    {
      icon: Moon,
      title: "Create a Bedtime Routine",
      description: "Develop a relaxing pre-sleep routine to signal to your body that it's time to wind down.",
      priority: avgQuality < 4 ? "high" : "low",
      category: "routine"
    }
  ];

  const priorityColors = {
    high: "from-red-500 to-pink-500",
    medium: "from-yellow-500 to-orange-500",
    low: "from-green-500 to-emerald-500"
  };

  const priorityLabels = {
    high: "High Priority",
    medium: "Medium Priority", 
    low: "Low Priority"
  };

  // Insights based on data
  const getPersonalizedInsights = () => {
    const insights = [];
    
    if (avgDuration < sleepData.goals.targetSleepHours) {
      insights.push({
        type: "warning",
        message: `You're averaging ${avgDuration.toFixed(1)} hours of sleep, which is below your ${sleepData.goals.targetSleepHours}h goal.`
      });
    }
    
    if (avgQuality < 3) {
      insights.push({
        type: "alert",
        message: "Your sleep quality has been below average. Consider implementing the high-priority recommendations."
      });
    }
    
    if (avgQuality >= 4) {
      insights.push({
        type: "success",
        message: "Great job! Your sleep quality is excellent. Keep up the good habits."
      });
    }
    
    return insights;
  };

  const insights = getPersonalizedInsights();

  return (
    <div className="space-y-8">
      <div className="text-center text-white">
        <h2 className="text-3xl font-bold mb-2">Sleep Recommendations</h2>
        <p className="text-white/80 text-lg">Personalized tips to improve your sleep quality</p>
      </div>

      {/* Personalized Insights */}
      {insights.length > 0 && (
        <div className="space-y-4">
          {insights.map((insight, index) => (
            <div
              key={index}
              className={`p-4 rounded-xl border ${
                insight.type === 'success' 
                  ? 'bg-green-500/20 border-green-400/30' 
                  : insight.type === 'warning'
                  ? 'bg-yellow-500/20 border-yellow-400/30'
                  : 'bg-red-500/20 border-red-400/30'
              }`}
            >
              <p className="text-white font-medium">{insight.message}</p>
            </div>
          ))}
        </div>
      )}

      {/* Sleep Score */}
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 text-center">
        <div className="flex items-center justify-center mb-4">
          <div className="relative">
            <div className="w-24 h-24 rounded-full border-8 border-white/20 flex items-center justify-center">
              <div className="text-3xl font-bold text-white">
                {Math.round((avgQuality / 5) * 100)}
              </div>
            </div>
            <div 
              className="absolute top-0 left-0 w-24 h-24 rounded-full border-8 border-transparent transition-all duration-500"
              style={{
                borderTopColor: avgQuality >= 4 ? '#10b981' : avgQuality >= 3 ? '#f59e0b' : '#ef4444',
                transform: `rotate(${(avgQuality / 5) * 360}deg)`
              }}
            />
          </div>
        </div>
        <h3 className="text-2xl font-bold text-white mb-2">Sleep Score</h3>
        <p className="text-white/70">
          Based on your recent sleep quality and duration
        </p>
      </div>

      {/* Recommendations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {recommendations.map((rec, index) => {
          const Icon = rec.icon;
          return (
            <div key={index} className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 hover:bg-white/15 transition-all duration-200">
              <div className="flex items-start space-x-4">
                <div className={`p-3 rounded-xl bg-gradient-to-r ${priorityColors[rec.priority]} flex-shrink-0`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-lg font-semibold text-white">{rec.title}</h4>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      rec.priority === 'high' ? 'bg-red-500/20 text-red-300' :
                      rec.priority === 'medium' ? 'bg-yellow-500/20 text-yellow-300' :
                      'bg-green-500/20 text-green-300'
                    }`}>
                      {priorityLabels[rec.priority]}
                    </span>
                  </div>
                  <p className="text-white/80 text-sm leading-relaxed">
                    {rec.description}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Sleep Hygiene Checklist */}
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
        <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
          <Lightbulb className="h-6 w-6 mr-3 text-yellow-400" />
          Sleep Hygiene Checklist
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            "Keep a consistent sleep schedule",
            "Create a relaxing bedtime routine", 
            "Keep your bedroom cool and dark",
            "Avoid large meals before bedtime",
            "Get regular exercise (but not too close to bedtime)",
            "Manage stress through relaxation techniques",
            "Limit daytime naps to 20-30 minutes",
            "Use comfortable bedding and pillows"
          ].map((item, index) => (
            <div key={index} className="flex items-center space-x-3 text-white/80 hover:text-white transition-colors">
              <div className="w-2 h-2 bg-blue-400 rounded-full flex-shrink-0"></div>
              <span className="text-sm">{item}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Recommendations;